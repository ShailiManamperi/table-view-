package lk.ijse.example.to;

import lk.ijse.example.db.DBConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Database {
   // public static ArrayList<employee> employeeTable =new ArrayList<>();
    public static ArrayList<employee> employeeTable;

    static {
        try {
            employeeTable= getAllEmployee();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<employee> getAllEmployee() throws ClassNotFoundException, SQLException {
        ResultSet rst = DBConnection.getInstance().getConnection()
                .createStatement().executeQuery("Select * From employee");

        ArrayList<employee>employeeList=new ArrayList<>();

        while(rst.next()){
            employee e1 = new employee( rst.getString("id"),
                                        rst.getString("name"),
                                        rst.getString("address"),
                                        rst.getString("contact")
                                        );
            employeeList.add(e1);
        }
        return employeeList;
    }
}
