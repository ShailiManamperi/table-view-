package lk.ijse.example.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import lk.ijse.example.to.Database;
import lk.ijse.example.to.employee;
import lk.ijse.example.to.employeeTM;

import java.io.IOException;
import java.util.Objects;

public class TableexampleController {

    public TableView tblemployee;
    public TableColumn colid;
    public TableColumn colname;
    public TableColumn coladdress;
    public TableColumn colcontact;
    public TableColumn colshow;

    public void initialize() throws IOException {
        colid.setCellValueFactory(new PropertyValueFactory<employeeTM, String>("id"));
        colname.setCellValueFactory(new PropertyValueFactory<employeeTM,String >("name"));
        coladdress.setCellValueFactory(new PropertyValueFactory<employeeTM,String >("address"));
        colcontact.setCellValueFactory(new PropertyValueFactory<employeeTM,String >("contact"));
        colshow.setCellValueFactory(new PropertyValueFactory<employeeTM,String >("btn"));
        setData();
    }

    private void setData() {
        ObservableList<employeeTM> list = FXCollections.observableArrayList();
        Database ob = new Database();
        for (employee obj : ob.employeeTable) {
            Button b = new Button("Show");
            employeeTM n = new employeeTM(
                    obj.getId(),
                    obj.getName(),
                    obj.getAddress(),
                    obj.getContact(),
                    b
            );
            b.setOnAction(e -> {
                System.out.println("sucess");
            });
            tblemployee.getItems().add(n);
        }
    }

}
