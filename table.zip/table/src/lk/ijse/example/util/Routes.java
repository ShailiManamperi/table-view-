package lk.ijse.example.util;

public enum Routes {
}
